function checkBrowser(){
	this.ver = navigator.appVersion;
	this.name = navigator.appName;
	this.mac = (navigator.platform.toLowerCase().indexOf('mac')>-1)?true:false;
	this.opera = (navigator.userAgent.toLowerCase().indexOf('opera')>-1)?true:false;
	this.dom = document.getElementById?true:false;
	this.ns = (this.name=='Netscape');
	this.ie4 = (document.all && !this.dom)?true:false;
	this.ie = (this.name =='Microsoft Internet Explorer'&&!this.opera)?true:false;
	this.ie5 = (this.ie && (navigator.userAgent.indexOf("MSIE 5")!=-1))?true:false;
	this.macie50 = (this.mac&&this.ie5&&(navigator.userAgent.indexOf("MSIE 5.0")!=-1))?true:false
	this.ns4 = (this.ns && parseInt(this.ver) == 4)?true:false;
	this.ns6 = ((this.name=="Netscape")&&(parseInt(this.ver)==5))?true:false
	this.standards = document.getElementById?true:false;
	this.dhtml = this.standards || this.ie4 || this.ns4;
}