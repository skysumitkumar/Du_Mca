function gotoPage(pageName) {
	window.location.href = pageName;
}

function showRemote(url, wname, w, h) {
	self.name = "main"; // names current window as "main"
	var windowprops = "toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=0,resizable=0,width=" + w + ",height=" + h + ",left=50,top=50";
	OpenWindow = window.open(url, wname, windowprops); // opens remote control
}