 var agt = navigator.userAgent.toLowerCase();
 var is_ie     = ((agt.indexOf("msie") != -1) && (agt.indexOf("opera") == -1));

function ENN_validate_sb_cio (form) {
	
	var y = ENN_get_value(form.action_sb_cio);
	if (y != 1 && !ENN_get_value(form.sb_cio_skip)) {
		alert("Sorry, we are unable to process your request unless you select 'Yes' to receive your free copy of CIO Today at the top of the page.");
		ENN_center_on_element(form.action_sb_cio);
		return false;
	}

	if (form.action_passwd) {
		if (form.action_passwd.value != form.passwd2.value) {
			alert("Passwords do not match");
			ENN_center_on_element(form.action_passwd);
			return false;

		}


	}
	if (form.email2) {
		if (form.action_sb_cio_generic_email.value != form.email2.value) {
			alert("E-Mail addresses do not match");
			ENN_center_on_element(form.action_sb_cio_generic_email);
			return false;
		}
	}
	if (!ENN_check_sb_country_state(form))
		return false;
	if (!ENN_check_required(form))
		return false;
	if (!ENN_check_optional(form))
		return false;
	if (!ENN_check_others(form))
		return false;
	
	return true;
		
	
			

}


function ENN_check_sb_country_state(form) {
	
	var p = new RegExp("action_(sb_\\w{3}_ship_)?country","");
	var r = /action_(sb_\w{3}_ship_)?country/;
	
	for (c in form) {
		
		var res = p.exec(c);
		
		if (!res) {
			var t = new String(c);
			res = t.match(r);
		}
		
		if (res) {
			var message;
			if (res[1]) {
				
				scheck = 'action_' + res[1] + 'state';
				acheck = 'action_' + res[1] + 'address1';
				message = 'Please Enter State/Province information on Address (line 2) for your "Alternate Delivery Address"';
			}
			else {
				scheck = 'action_state';
				acheck = 'action_address1';
				message = 'Please Enter State/Province information on Address (line 2) for your "Business Mailing Address"'; 		
			}
			var country = ENN_get_value(form.elements[res[0]]);
			if (!country)
				continue;
				
			if (!(country == '228' || country == '36')) {
				var menu = form.elements[scheck];
				
				if (ENN_get_value(menu) != 111) {
					for (i = 0; i < menu.length; i++) {
						if (menu[i].value == 111)
							menu.selectedIndex = i;
					}
					
				}
				if (!ENN_get_value(form.elements[acheck])) {
					ENN_center_on_element(form.elements[acheck]);
					alert(message);
					return false;
				}
			}
		}
	}
	return true;
}
	
function ENN_check_others (form) {
	for (ob in others) {
		if (typeof form.elements["action_" + ob + "_specified"] != 'object') {
			continue;
		}
		var found_error;
		var focus = "";
		var arystyle = "action[]_" + ob;
		var sstyle = "action_" + ob;
		var check = form.elements[sstyle] || form.elements[arystyle];
		
		var specified = form.elements["action_" + ob + "_specified"];
		var val = ENN_get_value(check);
		if ((val == others[ob]) &&  !specified.value) {

			found_error = "Please use the text box to specify a " + others_desc[ob] + ".";
			focus = specified;

		}

		if (found_error) {
			alert(found_error);
			ENN_center_on_element(focus);
			return false;
		}
	}
	return true;
}

function ENN_check_optional (form) {
	var op_specified;
	
	for (tp in optional) {
		var val;
		for (name in optional[tp]) {
			arystyle = "action[]_" + name;
			sstyle = "action_" + name;
			ob = form.elements[sstyle] || form.elements[arystyle];
			if (!ob) 
					continue;
			val = ENN_get_value(ob);
			if (val) {
				op_specified = true;
			}
		}
	}
	if (op_specified) {
		for (tp in optional) {
			desc = "";
			var val = "";
			var focus = "";
			for (name in optional[tp]) {

				if (optional[tp][name]) {
					desc = optional[tp][name];
				}
				if (!val) {
					arystyle = "action[]_" + name;
					sstyle = "action_" + name;
					ob = form.elements[sstyle] || form.elements[arystyle];
					focus = (ob.scrollHeight) ? ob : ob[0];
					val = ENN_get_value(ob);
					if (!val && form.elements[name + "_skip"])
						val = form.elements[name + "_skip"].value;
				}
			}
			if (!val) {
				alert(desc);
				ENN_center_on_element(focus);
				return false;
			}

		}

	}
	return true;
}

function ENN_check_required (form) {
	for (tp in required) {

		desc = "";
		var val = "";
		var focus = ''; 
		for (name in required[tp]) {
			if (required[tp][name]) {
				desc = required[tp][name];
			}
			if (!val) {
				arystyle = "action[]_" + name;
				sstyle = "action_" + name;

				ob = form.elements[sstyle] || form.elements[arystyle];
				if (!ob) 
					continue;
				focus = (ob.scrollHeight) ? ob : ob[0];
				//exempt a required element if there is a name_skip element that is set
				val = ENN_get_value(ob);
				if (!val && form.elements[name + "_skip"])
					val = form.elements[name + "_skip"].value;

			}

		}
		if (!val) {
			alert(desc);
			ENN_center_on_element(focus);
			return false;
		}
	}
	return true;
	

}

function ENN_get_value (item) {
	if (!item)
		return false;
	if (!item.type) {
		for (i = 0; i < item.length; i++) {
			if (item[i].checked == true) {
				return item[i].value;
			}
		}
	}
	else if (item.type == 'select-one'){
		return item[item.selectedIndex].value;
	}
	else {

		return item.value;
	}

}
function ENN_center_on_element (element) {
	if (!element)
		return false;
		
	if (!element.type) {
		element = element[0];
	}
	element.focus();
	height = ENN_get_window_dimensions().height;

	height = Math.round(height / 2);
	var dim = ENN_get_coords(element);
	dim.top -= height;
	window.scroll(0, dim.top);
}

function ENN_get_coords (element) {
	
	var dim = new Object();
	dim.top = 0;
	dim.left = 0;
	if (element) {
		if (element.offsetParent) {
			while (element.offsetParent)
			{
				dim.top += element.offsetTop;
				dim.left += element.offsetLeft;
				element = element.offsetParent;
			}
		}
		else if (element.y || element.x) {
			dim.top += element.y;
			dim.left += element.x;
		}
	}
	dim.x = dim.left;
	dim.y = dim.top;
	return (dim);
}

function ENN_get_window_dimensions () {
	var myWidth = 1, myHeight = 1; //avoid divide by zeros

	if( typeof( window.innerWidth ) == 'number' ) {
		//Non-IE
		myWidth = window.innerWidth;
		myHeight = window.innerHeight;
	} 
	else {
		if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
			//IE 6+ in 'standards compliant mode'
			myWidth = document.documentElement.clientWidth;
			myHeight = document.documentElement.clientHeight;
		} 
		else {
			if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {
				//IE 4 compatible
				myWidth = document.body.clientWidth;
				myHeight = document.body.clientHeight;
			}
		}
	}
	var ret  = new Object();
	ret.width = myWidth;
	ret.height = myHeight;
	return ret;
}

function ENN_positionBottom () {

	if (document.getElementById) {

		bottom = document.getElementById('content-bottom');

		main = document.getElementById('content-main');
		mainh = ENN_get_coords(main).top + main.offsetHeight;

		nav = document.getElementById('content-nav');
		navh = ENN_get_coords(main).top + nav.offsetHeight;

		bottom.style.top = ((mainh > navh) ? mainh : navh)   + 'px';
		bottom.style.display = 'block';
	}



}

var ssectionitem;
var ssectionitemhover;

function ENN_dogbone_color(obj,state) {
		if (!is_ie) {
			return true;
		}
		rules = document.styleSheets[0].rules;
		if (! ssectionitem) {

			for (i = 0; i < rules.length; i++) {
				if (rules[i].selectorText == '.sectionitem') {
					ssectionitem = i;
				}
				else if (rules[i].selectorText == '.sectionitem:hover') {
					ssectionitemhover = i;
				}
			}
		}
		if (state ==  'on') {
			obj.style.backgroundColor = rules[ssectionitemhover].style.backgroundColor;
			obj.style.color = rules[ssectionitemhover].style.color;
		}
		else if (state == 'off') {
			obj.style.backgroundColor = rules[ssectionitem].style.backgroundColor;
			obj.style.color = rules[ssectionitem].style.color;
		}


}