function sf() {
  if (document.tourform) {
     document.tourform.month.focus();
  };
  if (document.nmrlform) {
     document.nmrlform.month.focus();
  };
}
