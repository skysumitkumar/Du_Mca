/*
selected javascript functions/code/algorithms from
abel banda (www.abelbanda.com)
talk2darwin@darwinsolutions.com
(c) 2001, Darwin IT Solutions, Abel Banda, All Rights Reserved.
Unauthorized Use Prohibited & Subject to Prosecution/Legal Action/Royalty Fee Payment.
*/

var preloadFlag = false;

function nav1Over(what)	{
	if (what == 'curriculum')	{
		SwapImage('curriculum','/img/b_curriculum_01.jpg');
	} else	{
		SwapImage('curriculum','/img/b_curriculum_03.jpg');
	}
	if (what == 'elearning')	{
		SwapImage('elearning','/img/b_elearning_01.jpg');
	} else	{
		SwapImage('elearning','/img/b_elearning_03.jpg');
	}
	if (what == 'events')	{
		SwapImage('events','/img/b_events_01.jpg');
	} else	{
		SwapImage('events','/img/b_events_03.jpg');
	}
	if (what == 'knowledge')	{
		SwapImage('knowledge','/img/b_knowledge_01.jpg');
	} else	{
		SwapImage('knowledge','/img/b_knowledge_03.jpg');
	}
	if (what == 'projects')		{
		SwapImage('projects','/img/b_projects_01.jpg');
	} else	{
		SwapImage('projects','/img/b_projects_03.jpg');
	}
}

function nav1Reset()	{
	SwapImage('curriculum','/img/b_curriculum_00.jpg');
	SwapImage('elearning','/img/b_elearning_00.jpg');
	SwapImage('events','/img/b_events_00.jpg');
	SwapImage('knowledge','/img/b_knowledge_00.jpg');
	SwapImage('projects','/img/b_projects_00.jpg');
	return;
}

function SwapImage(what,img_name) {
	eval("document." + what + ".src='" + img_name + "'");
	return;
}

function newImage(arg) {
	if (document.images) {
		rslt = new Image();
		rslt.src = arg;
		return rslt;
	}
}

function preloadImages() {
	if (document.images) {
		curriculum_over_01 = newImage("/img/b_curriculum_01.jpg");
		curriculum_over_03 = newImage("/img/b_curriculum_03.jpg");
		elearning_over_01 = newImage("/img/b_elearning_01.jpg");
		elearning_over_03 = newImage("/img/b_elearning_03.jpg");
		events_over_01 = newImage("/img/b_events_01.jpg");
		events_over_03 = newImage("/img/b_events_03.jpg");
		knowledge_over_01 = newImage("/img/b_knowledge_01.jpg");
		knowledge_over_03 = newImage("/img/b_knowledge_03.jpg");
		projects_over_01 = newImage("/img/b_project_01.jpg");
		projects_over_03 = newImage("/img/b_project_03.jpg");
		preloadFlag = true;
	}
}

function abOpen(strFileName)	{
	window.open (strFileName,"Win","width=360,height=150")
	return;
}