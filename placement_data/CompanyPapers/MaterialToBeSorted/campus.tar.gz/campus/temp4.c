#include<stdio.h>
   main()
     {
     int a,b;
     printf("enter two numbers :");
     scanf("%d%d",a,b);
     printf("%d+%d=%d",a,b,a+b);
     }
