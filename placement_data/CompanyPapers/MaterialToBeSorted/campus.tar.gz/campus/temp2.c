#include<stdio.h>
main()
{
        int i=10;
        printf("%d %d %d",i,++i,i++);
}
