				TCS

    Source : University of Roorkee
    Dated  : 31/07/97


     1. VOCABULARY.(SYNONYMS)               40 BITS.    20 MARKS. 20MIN.
     2. QUANTITATIVE APTITUDE               15 BITS     30 MARKS  15 MIN.
     3. CRITICAL REASIONING.(COMPREHENSION) 50 BITS     50 MARKS  25 MIN.
     4. PSYHOMETRIC TEST.                   150 BITS    150 MARKS 30 MIN
							--------  ------
						       250 MARKS   90 MIN
							--------  -------


		       THE PSYCHOMETRIC TEST IS SIMPLE  AND THERE IS NO
    NEED OF OF PREPARATION. IT SIMPLY TEST YOUR PSYCHOLOGY. GIVE MOST
    POSITIVE  ANSWERS TO THIS SECTION. I AM SENDING SOME QUESTIONS TO
    YOU. THE VOCAB. IS SAME. BUT THERE IS SOME CHANGES IN PASSAGES.BUT
    THE IDEA IS SAME.

     TAKE FOLLOWING PRECAUTIONS WHILE ANSWERING TEST.
     -------------------------------------------------------------
    1.  DON'T WRITE FULL ANSWERS  TO VOCAB. SECTION. DO ONLY 36 to 37
	QWUE's.BECAUSE THEY DISQUALIFIED SOME CANDIDATES HERE.

    2.  WE ARE SENDING ANSWERS TO THIS SECTION. SO YOU SIMPLY MUG UP
	ANSWERS.

    3.  FOR CRITICAL REASONING SECTION WE ARE  SENDING ANSWERS.BUT
	SOME OF THESE ANSWERS MAY CHANGE. SO YOU PLEASE CHECK IN
	EXAMINATION. THE ANSWERS IS SIMPLY (TRUE) OR (FALSE) OR
	(CAN'T SAY) TYPE.  FOR THIS SECTION YOU HAVE READ AS FAST
	AS YOU CAN. IT SIMPLY TEST YOUR COMPREHENSION ABILITY.

     4.  EVENTHOUGH  WE ARE SENDING ANSWERS TO MATHEMATICAL ABILITY.
	 SECTION. YOU DO " ROUGH " WORK BACK OF YOUR PAGE. IT IS ALSO
	 ONE OF IMPORTNANT CAUTION.

     5.  IN PSYCHOLOGY SECTION THE QWE'S MAY REPEATE AT LEAST FOUR
	 TIMES. BY SIMPLY CHANGING SENTENCE FORMATION. SO BECAREFUL
	 GIVE SAME ANSWERS TO THOSE QWE'S.





THERE WILL BE NO NEGATIVE MARKING. TIME 90 Min., APPEARED FOR EXAM =255 STUDENTS
SELECTED FOR INTERVIEW =122,        FINALLY SHORT LISTED = 55 STUDENTS.

SECTION I   VOCABULARY (SYNONYMS) TIME :15 Min.   MARKS: 20.
DIRECT ANSWERS :
-----------------------------------------------------------------
Admonish : usurp         Meager :scanty         Alienate : estrange
Merry : gay              Brim : Boarder         obstinate : stubborn
Pretention:pretentioius  Tranquil:serene        solicit : urge
subside : wane           furtive :stealthy      misery : disstress
volume :quantity         veer : diverge         stiffle :sniths
adhesive : ---           Hamper : obstruct      belief : conviction
lament : wail            to merit :to deserve   incentive : ----
inert: passive           Baffle : Frustrate     Confiscate : appropriat
Covet : crave            Caprice : whim         Concur :acquiesce
Cargo :freight           Dispel :  Scatter      Divulge : -----
Discretion: prudence     Emancipate : liberate  Efface : obliterate
Hover : linger           Heap : to pile         Instigate : incite
latitude : scope         latent : potential     lethergy : stupor
momentary : transient
 ----- means , for these words we are not able to reproduce answers.

PART II   QUANTITATIVE APTITUDE ,TIME 20 Min. MARKS :30.
-----------------------------------------------------------------
	1. Two pencils costs 8 cents, then 5 pencils cost how much
	(Ans:20 cents).
	2. A work is done by the people in 24 min. one of them can do
	this work a lonely in 40 min. how much time required to do the same
	work for the second person.
	 (ans:60 min.)
	3. A car is filled with four and half gallons of oil for full round
	trip. fuel is taken 1/4 gallons mor3 in going than coming. what is
	the fiel consumed in coming up? (2 gallons)
	4. low temperature at the night in a city is 1/3 more than 1/2
	hinge as higher temperature in a day. sum of the low temp and
	higherst temp is 100C. then what is the low temperature (40 C)
	5. A person who decided to go weekend trip should not exceed 8 hours
	 driving in a day Average speed of forward journy is 40 mph. due to
	 traffic in sundays, the return journey average speed is 30 mph.
	 how far he can select a picnic spot (120 miles).

	6. A sales person multiplied a number and get the answer is 3,
	instead of that number divided by 3. what is th answer he actually
	has to get ? (1/3).
	7. A ship started from port and moving with I mph and another ship
	started from L and moving with H mph. At which place these two ships
	 meet ?  ( Ans is between  I and J and close to J)

	     !_____!_____!_____!_____!_____!_____!
	    port   G     H     I     J     K     L

	8. A building with hight D ft shadow upto G A neighbour building with
	 what height shadow C ft is      (B ft.)

	  !_____!_____!_____!_____!_____!_____!_____!
	  A     B     C     D     E     F     G     H

	9. A person was fined for exceeding the speed limit by 10 mph.Another
	 person was also fined for exceeding the same speed limit by twice
	 the same.  If the second person was travelling at a speed of 35 mph.
	 find the speed limit (15 mph)

	10. A bus started from bustand at 8.00a m and after 30 min staying at
	destination, it returned back to the bustand.  the destination is 27
	 miles from the bustand. the  speed of the bus 50 percent fast speed.
	  at what time it retur4ns to the bustand (11.00)

	11.in a mixture, R is 2 parts, S is 1 part. in order to make S to 25%
	of the mixture, howmuch R is to be added   ( one part).

	12. wind flows 160 miles in 330 min, for 80 miles how much time
	required.
	13. with 4/5 full tank vehicle travels 12 miles, with 1/3 full tank
	how much distance travels  ( 5 miles).

	14. two trees are there. one grows at 3/5 of the other. in 4 years,
	total growth of trees is 8 ft.  what growth will smaller tree will
	have in 2 years.  (<2ft)

	15. A storm will move with a velocity of    towords the center in
	 hours. At the same rate how much far will it move in hrs.
	 (but Ans is 8/3 or 2 2/3).

PART III: TIME 25 Min, MARKS :50.
-----------------------------------------------
CRITICAL REASONING : THERE WILL BE 13 PASSAGES WITH 50 QUESTIONS TIME 30 MIN.
HERE I AM SENDING ONLY SOME OF THE PASSAGES (these will give only rough idea)
(ANSWERS WILL BE AS  YES/NO/CAN'T SAY we are giving our answers, please check.)

1. My father has no brothers. he has three sisters who has two childs each.

      1> my grandfather has two sons (f)
      2> three of my aunts have two sons(can't say)
      3> my father is only child to his father(f)
      4> i have six cousins from my mother side(f)
      5> i have one uncle(f)

2. Ether injected into gallablader to dissolve galstones. this type oneday
treatment is enough for gallstones not for calcium stones. this method is
alternative to surgery for millions of people who are suffering from this
disease.
      1> calcium stones can be cured in oneday (f)
      2> hundreds of people contains calcium stones(can't say)
      3> surgery is the only treatment to calcium stones(t)
      4> Eather will be injected into the gallbleder to cure the cholestrol
      based gall stones(t).

3. Hacking is illigal entry into other computer. this is done mostly
because of lack of knowledge of computer networking with networks one
machine can access to another machine. hacking go about without knowing
that each network is accredited to use network facility.
	1> Hacking people never break the code of the company which they
	work for (can't say).
	2> Hacking is the only vulnerability of the computers for the usage
	of the data.(f)
	3> Hacking is done mostly due to the lack of computer knowledge (f).
   (there will be some more questions in this one )

4. alphine tunnels are closed tunnels. in the past 30 yrs not even a single
accident has been recorded for there is one accident in the rail road
system. even in case of a fire accident it is possible to shift the passengers
into adjacent wagons and even the living fire can be detected and extinguished
with in the duration of 30 min.
	1> no accident can occur in the closed tunnels (True)
	2> fire is allowed to live for 30 min.  (False)
	3> All the care that travel in the tunnels will be carried by rail
	shutters.(t)
	4>

5. In the past helicopters are forced to ground or crash because of the
formation of the ice on the rotors and engines. a new electronic device has
been developed which can detect the watercontent in the atmosphere and warns
the pilot if the temp.is below freezing temp. about the formation of the ice
on the rotors and wings.
	1> the electronic device can avoid formation of the ice on the wings (False).
	2> There will be the malfunction of rotor & engine because of formation of ice (t)
	3> The helicopters are to be crashed or down (t)
	4> There is only one device that warn about the formation of ice(t).

6.In the survey conducted in mumbai out of 63 newly married house wives not a single house
wife felt that the husbands should take equal part in the household work as
they felt they loose their power over their husbands. inspite of their careers
they opt to do the kitchen work themselves after coming back to home. the
wives get half as much leisure time as the husbands get at the week ends.
	1> housewives want the husbands to take part equally in the household(f)
	2> wives have half as much leisure time as the husbands have(f)
	3> 39% of the men will work equally in the house in cleaning and washing
	3>

7. copernicus is the intelligent. In the days of copernicus the transport and technology
development was less & it took place weeks to comunicate a message at that
time.wherein we can send it through satellite with in no time ----------.
even with this fast developments it has become difficult to understand each other.
	1> people were not intelligent during Copernicus days (f).
	2> Transport facilities are very much improved in noe a days (can' say)
	3> Even with the fast developments of the techonology we can't live happily.(can't say)
	4> We can understand the people very much with the development of communication(f).

    Q8) senior managers warned the workers that because of the intfoductors
    of japanese industry in the car market. There is the threat to the workers.
      They also said that there will be the reduction in the purchase of the sales of
      car in public.the interest rates of the car will be increased with the loss in demand.
    1> japanese workers are taking over the jobs of indian industry.(false)
    2> managers said car interests will go down after seeing the raise in interest rates.(true)
    3> japanese investments are ceasing to end in the car industry.(false)
    4> people are very much interested to buy the cars.(false)

    Q9) In the totalitariturican days,the words have very much devalued.In
    the present day,they are becoming domestic that is the words will be much more devalued.
    In that days, the words will be very much effected in political area.but
    at present,the words came very cheap .we can say they come free at cost.
     1> totalitarian society words are devalued.(false)
     2> totalitarian       will have to come much about words(t)
     3> The art totalitatian society the words are used for the political speeches.
     4>

      Q10) There should be copyright for all arts. The reele has came that all the
      arts has come under one copy right society,they were use the money that come from
      the arts for the developments . There may be a lot of money will come from
      the Tagore works. We have to ask the benifiters from Tagore work to help for
      the development of his works.
     1> Tagore works are came under this copy right rule.(f)
     2> People are free to go to the       because of the copy right rule.(can't say)
     3> People gives to theater and collect the money for development.(can't say)
     4> We have  ask the Tagore resedents to help for the developments of art.(can't say)

NOTE :  DO 1,2,3,4,5 PASSAGES WHICH ARE EASY. LAST BUT ONE ALSO. DO THAT
PASSAGES CAREFULLY. TIME WILL BE INSUFFICIENT. PASSAGES ARE NOT AS EXACTLY
AS ABOVE. THERE IS HIGHLEVEL ENGLISH IN ALL THE PASSAGES, WE ARE GIVING
IN OUR OWN WORDS , U CANNOT EXPECT THE SAME TYPE OF ENGLISH THERE. WHILE
ANSWERING U SHOULD BE VERY FAST, DO NOT WASTE TIME, IT IS INSUFFICIENT,TRY TO ANSWER
AS MANY AS POSSIBLE.

SECTION 4.  PSYCHOMETRIC TEST.
----------------------------------------
DO NOT BOTHERE ABOUT MUCH ABOUT THIS TEST. BE OPTIMISTIC WHILE ANSWERE.
THERE WILL BE 150 QUESTIONS IN 30 MIN. THE QUESTIONS IN THIS SECTION MAY
REPEATED WITH SLIGHT VARIATIONS ANSWER SHOULD BE SAME IN BOTH THE CASES.
(ans will be as yes/no/can't say)

for example
1> you will be interested in social activities.
2> while going upstairs you will move two steps at a time.
3> you will be making friendship with same sex or with opposite sex also.
4> your friends will consider u as a leader in your group
5> people think that your'e serious minded.
6> some times you feel dull without any reason.
7> your'e host or hostes for several parties.
8> relatives come to your house you will entertain them.
9> you will do work for longtime without tireness.
10> in your company you want lead the organasition.
etc..  the qwestions may repeate several times so becareful and give same ans's.
