/* ALLOCM2.C: resolutions to allocation problems in ALLOCM1
*/

#include <alloc.h>			// for farmalloc()
#include <dos.h>				// for allocmem()
#include <stdio.h>			// for printf()

//*******************************************************************
main()
{
#pragma warn -aus				// ptr IS assigned a value that isn't used!
	unsigned seg, count = 0;
	char far *ptr;

	_AX = 0x5801;
	_BX = 2;
	geninterrupt(0x21);    // set allocation strategy to last fit
	allocmem( 100, &seg ); // grab highest block
	_AX = 0x5801;
	_BX = 0;
	geninterrupt(0x21);    // reset allocation strategy
	printf(" Allocated block at %X:0000\n", seg);
	while ((ptr = (char far*) farmalloc(50)) != NULL)
		count++;
	printf(" Allocated %u 50 byte pieces\n", count);

	return 0;
} // end of main()

