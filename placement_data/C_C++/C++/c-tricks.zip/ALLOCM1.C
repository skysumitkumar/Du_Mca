/* ALLOCM1.C: shows conflict in memory allocation schemes
*/

#include <alloc.h>			// for farmalloc()
#include <dos.h>				// for allocmem()
#include <stdio.h>			// for printf()

//*******************************************************************
main()
{
#pragma warn -aus				// ptr IS assigned a value that isn't used!
	unsigned seg, count = 0;
	char far *ptr;

  // allocates next available block
	allocmem( 100, &seg );
	printf(" Allocated block at %X:0000\n", seg);
	while ((ptr = (char far*) farmalloc(50)) != NULL)
    count++;

  // can't allocate!
	printf(" Allocated %u 50 byte pieces\n", count);

  return 0;
} // end of main()
