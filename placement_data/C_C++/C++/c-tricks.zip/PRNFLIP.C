/* PRNFLIP.C: Program to Swap LPT1: and LPT2: Printer Devices
*/

#include <dos.h>		// for MK_FP()

//*******************************************************************
int main(void)
{
	unsigned far *LPT1_Addr = (unsigned far*) MK_FP(0x40, 0x08);
	unsigned far *LPT2_Addr = (unsigned far*) MK_FP(0x40, 0x0A);
	unsigned temp;

	temp  = *LPT1_Addr;
	*LPT1_Addr = *LPT2_Addr;
	*LPT2_Addr = temp;
	return 0;
} // end of main()
