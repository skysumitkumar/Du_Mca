/*-------------------------------------------------------------------------
				PR v 1.0
    (Printing Non-Printable Characters on Epson 9 pin DotMatrix Printer)
	Logic: Print all printable characters and Epson charaters with
	       Epson Character Set. Hence it is faster.
	       For all other non-printable characters, printing is achieved
	       by getting the font map from ROM and setting the printer to
	       graphics mode.
				   by
			   R. Rajesh Jeba Anbiah,
				 99MCA30
			   rrjanbiah@yahoo.com
			http://RajeshAnbiah.itgo.com
	File name: Pr.c
	Written: March-April, 2001
	Copyright (c) 2001, R. Rajesh Jeba Anbiah
	All Rights Reserved.
 *-----
 */

#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include <bios.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#define	PRINTER_WRITE	( 0 )
#define PRINTER_STATUS	( 2 )
#define	ESC		( 27 )
#define LPT1		( 0 )

#define FNTHEIGHT	( 8 )

void CopyRightInfo( void );
void Send2LPT1( int num, ... );
void SetLineSpacingTo1by8( void );
void SetPrinter2GraphicsMode( void );
void PrintWithEpsonCharSet( unsigned char ch );

/*---------------------------------------------------------------
	CopyRightInfo - Prints Copy Right Information 	     	*/

void CopyRightInfo( void )
{
    textbackground( BLACK );
    window( 1, 1, 80, 25 );
    clrscr( );
    textcolor( LIGHTGREEN );
    textbackground( BLACK );
    window( 10, 6, 75, 24 );
    cprintf(
	"�����������������������������������������������������������ͻ \r\n"
	"�                        PR   v 1.0                         � \r\n"
	"�            Print Non-Printable Characters on              � \r\n"
	"�             Epson 9 pin DotMatrix Printers                � \r\n"
	"�����������������������������������������������������������Ķ \r\n"
	"�                           by                              � \r\n"
	"�                  R. Rajesh Jeba Anbiah                    � \r\n"
	"�                Email: rrjanbiah@yahoo.com                 � \r\n"
	"�           Web page: http://RajeshAnbiah.itgo.com          � \r\n"
	"�����������������������������������������������������������Ķ \r\n"
	"�   Copyright (c) April 2001, R. Rajesh Jeba Anbiah         � \r\n"
	"�   All Rights Reserved.                                    � \r\n"
	"�����������������������������������������������������������ͼ \r\n"
      );
} /*--CopyRightInfo( )----*/

/*---------------------------------------------------------------
	Send2LPT1 - Send 'num' characters to LPT1		*/

void Send2LPT1( int num, ... )
{
    va_list argptr;
    int i;
    va_start( argptr, num );
    for ( i=0 ; i<num ; ++i )
	biosprint( PRINTER_WRITE, va_arg( argptr, int ), LPT1 );
    va_end( argptr );
} /*--Send2LPT1( )-------------*/

/*---------------------------------------------------------------
	SetLineSpacingTo1by8 - Sets line spacing to 1/8 inch  	*/

void SetLineSpacingTo1by8( void )
{
    Send2LPT1( 2, ESC, '0' );
} /*--SetLineSpacingTo1by8( )------*/

/*---------------------------------------------------------------
   SetPrinter2GraphicsMode - Initializes printer to graphics mode */

void SetPrinter2GraphicsMode( void )
{
    Send2LPT1( 5, ESC, '*', 4, 8%256, 8/256 );	/* 80 dpi quality */
} /*--SetPrinter2GraphicsMode( )-------*/

/*---------------------------------------------------------------
   PrintWithEpsonCharSet - Initializes printer to Epson Extended
     Printer Character Set and print a single character 'ch'.
     Epson Character Set contains all printable characters, single
     line box characters and few other ASCII characters.
	  (It is faster than Graphics mode.)			*/

void PrintWithEpsonCharSet( unsigned char ch )
{
    Send2LPT1( 4, ESC, 'm', 4, ch );
} /*--PrintWithEpsonCharSet( )-------*/


int main( int argc, char *argv[] )
{
   FILE *fp;
   struct REGPACK regs;
   unsigned char ch;
   char far *font8x8, far *ptr;
   unsigned int segment, offset;
   int fntval, mask, powof2, status;
   register int i, j;

   /* call the bios interrupt to get the address of the desired font */
   regs.r_ax = 0x1130;
   regs.r_bx = 0x0300;
   intr( 0x10, &regs );
   /* make a far pointer font8x8 point to info returned by the bios call */
   offset = regs.r_bp;
   segment = regs.r_es;
   font8x8 = (char far*) MK_FP( segment, offset );

   CopyRightInfo( );
    /*---Check For any Errors-----> */
    if ( argc < 2 )
      {
       cprintf(
	 " Syntax: PR filename [ -bb | -nbb ]                         \a\r\n"
	 " -bb     Box Better. Box characters will appear better. But \r\n"
	 "         characters of adjacent lines may touch each other. \r\n"
	 "         (default)                                          \r\n"
	 " -nbb    No Box Better. Characters of adjacent lines won't  \r\n"
	 "         touch each other.                                  "
	);
       exit( 1 );
      }
    status = biosprint( PRINTER_STATUS, 0, LPT1 );
    if ( status & 0x01 )
	{
	   cprintf( " Fatal Error: Printer time out \a\r\n" );
	   exit( 1 );
	}
    if ( status & 0x08 )
	{
	   cprintf( " Fatal Error: I/O error \a\r\n" );
	   exit( 1 );
	}
    if ( (fp = fopen( argv[1], "rb"))==NULL )
	{
		perror( " Fatal Error\a" );
	   exit( 1 );
	}
    /*-- <---Error Checked...OK!  --*/

    /*  if switch is not equal to "-nbb", then do default ie, "-bb"  */
    if ( strcmpi( argv[2], "-nbb" )!=0 )
	SetLineSpacingTo1by8( );

    while ( !feof( fp ) )
    {
	fread( &ch, 1, 1, fp );
	if ( ch=='\r' || ch=='\n' || ch=='\a'|| ch=='\t'|| ch=='\v'
				  || ch=='\f'|| ch=='\b'|| ch==0
				  || ch==255 || (ch>=' '&&ch<='~') )
		PrintWithEpsonCharSet( ch );
	  else
	    {
		 switch( ch )
		  {
			/*  Box Characters adjust  */
			/*  upper left corner  */
			case  218:	/* '�' */
				    PrintWithEpsonCharSet( 135 );
				    break;
			/*   Upper right corner  */
			case  191:	/* '�' */
				    PrintWithEpsonCharSet( 136 );
				    break;
			/*   Lower left corner  */
			case  192:	/* '�' */
				    PrintWithEpsonCharSet( 137 );
				    break;
			/*   Lower right corner  */
			case  217:	/* '�' */
				    PrintWithEpsonCharSet( 138 );
				    break;
			/*   Middle left corner  */
			case  195:	/* '�' */
				    PrintWithEpsonCharSet( 132 );
				    break;
			/*   Middle right corner  */
			case  180:	/* '�' */
				    PrintWithEpsonCharSet( 131 );
				    break;
			/*   Middle top corner  */
			case  194:	/* '�' */
				    PrintWithEpsonCharSet( 130 );
				    break;
			/*   Middle bottom corner  */
			case  193:	/* '�' */
				    PrintWithEpsonCharSet( 129 );
				    break;
			/*   Center cross  */
			case  197:	/* '�' */
				    PrintWithEpsonCharSet( 128 );
				    break;
			/*   Horizontal  */
			case  196:	/* '�' */
				    PrintWithEpsonCharSet( 133 );
				    break;
			/*   Vertical  */
			case  179:	/* '�' */
				    PrintWithEpsonCharSet( 134 );
				    break;
			/*  Other ASCII Characters adjust  */
			case  6:    	/* spade */
				    PrintWithEpsonCharSet( 145 );
				    break;
			case  3:	/* heart */
				    PrintWithEpsonCharSet( 146 );
				    break;
			case  4:	/* diamond */
				    PrintWithEpsonCharSet( 147 );
				    break;
			case  5:	/* club */
				    PrintWithEpsonCharSet( 148 );
				    break;
			case  246:	/* '�' */
				    PrintWithEpsonCharSet( 158 );
				    break;
			case  241:	/* '�' */
				    PrintWithEpsonCharSet( 159 );
				    break;
			default:
				    mask = 128;
				    SetPrinter2GraphicsMode( );
				    for ( i=0; i<8; ++i )
				    {
				       /* make ptr point the start of the letter in the rom font each
					  character is FNTHEIGHT bytes with each bit in a byte being a
					  pixel on/off for that scan line of the charater
				       */
				       ptr = font8x8 + ( ch * FNTHEIGHT );
				       fntval = 0;
				       powof2 = 128;
				       for ( j=0 ; j<8 ; ++j )
				       {
					  fntval += (*ptr&mask) ? powof2 : 0;
					  ++ptr;  /* ptr points to the next scanline of the current character */
					  powof2 >>= 1;
				       }
				       biosprint( PRINTER_WRITE, fntval, LPT1 );
				       mask >>= 1;  /*  or dividing by 2  */
				    }
		  }
	    }
    }
   fclose( fp );
   return(0);
} /*--main( )------------*/
/*-------------------------
	Thank you Jesus!
______________________________end_________________________________________*/
