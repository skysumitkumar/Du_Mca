#include <dos.h>

#define	CMOS_ADDR	(0x70)		/* address port of CMOS */
#define	CMOS_DATA	(0x71)		/* data port for CMOS */

int main( void )
{
   int offset, data;
   const int size = 128;  /* or 64 depending upon your system */
   for ( offset=0; offset<size ; ++offset )
   {
	disable( );
	outportb( CMOS_ADDR, offset );
	data = inportb( CMOS_DATA );
	enable( );
	printf( "%0xX ", data );
   }
   return(0);
} /*--main( )---------*/