/*----------------------------------------------------------------------
	PAL - utility to extract palette from a BMP file
 *---
 */

#include <stdio.h>

#define BM_TYPE 19778u

typedef unsigned int WORD;
typedef unsigned long DWORD;
typedef unsigned char BYTE;

typedef struct tagBITMAPFILEHEADER
{
    WORD    bfType;
    DWORD   bfSize;
    WORD    bfReserved1;
    WORD    bfReserved2;
    DWORD   bfOffBits;
} BITMAPFILEHEADER;

typedef struct tagBITMAPINFOHEADER
{
    DWORD  biSize;
    DWORD  biWidth;
    DWORD  biHeight;
    WORD   biPlanes;
    WORD   biBitCount;
    DWORD  biCompression;
    DWORD  biSizeImage;
    DWORD  biXPelsPerMeter;
    DWORD  biYPelsPerMeter;
    DWORD  biClrUsed;
    DWORD  biClrImportant;
} BITMAPINFOHEADER;

typedef struct tagRGBQUAD {
    BYTE    rgbBlue;
    BYTE    rgbGreen;
    BYTE    rgbRed;
    BYTE    rgbReserved;
} RGBQUAD;

int main( int argc, char *argv[] )
{
   BITMAPFILEHEADER fheader,  *header = &fheader;
   BITMAPINFOHEADER finfo,  *info = &finfo;
   RGBQUAD trgb, *rgb = &trgb;
   FILE *bfp, *pfp;
   short num_col;
   int i;

   if ( argc < 3 )
      {
	 printf( "Usage: PAL file.bmp palfile\n\a" );
	 exit( 1 );
      }
   bfp = fopen( argv[1], "rb" );
   pfp = fopen( argv[2], "w" );
   if ( bfp==NULL || pfp==NULL )
      {
	  printf( "File Error!\n\a" );
	  exit( 1 );
      }
   fprintf( pfp, "/*  Palette file created with PAL  */\n"
		 "/*  File name: %s  */\n"
		 "BYTE pal[768] = { ", argv[2]
	  );
   fread( header, sizeof( BITMAPFILEHEADER ), 1, bfp );
   fread( info, sizeof( BITMAPINFOHEADER ), 1, bfp );
   if ( header->bfType != BM_TYPE )
	  printf( "%s is not a bmp!\n\a", argv[1]);
     else
       {
	  /*  We only handle 256 colour types with this code!  */
	  if ( info->biPlanes == 1 && info->biBitCount == 8 )
	     {
		num_col = info->biClrUsed ? info->biClrUsed : 256;
		for ( i=0; i <  num_col-1; ++i )
		 {
		    fread( rgb, sizeof( RGBQUAD ), 1, bfp );
		    if ( i%4 == 0 )
			fprintf( pfp, "\n\t\t %d, %d, %d,", rgb->rgbRed>>2, rgb->rgbGreen>>2, rgb->rgbBlue>>2 );
		      else
			fprintf( pfp, "\t%d, %d, %d,", rgb->rgbRed>>2, rgb->rgbGreen>>2, rgb->rgbBlue>>2 );
		 }
		fread( rgb, sizeof( RGBQUAD ), 1, bfp );
		fprintf( pfp, "\t%d, %d, %d\n\t};\n", rgb->rgbRed>>2, rgb->rgbGreen>>2, rgb->rgbBlue>>2 );
		fprintf( pfp, "/*_______EOF %s _________________________*/", argv[2] );
	      }
	    else
	       printf("This code only does 256 colour BMP's\n");
       }
   fcloseall( );
   return(0);
} /*---------------------
	Thank you Jesus!
_____________________________end_____________________________________*/
