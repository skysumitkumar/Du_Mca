#include <dos.h>

#define BufferX		(320L)   /* Width of screen buffer */
#define BufferY		(104L)   /* Height of screen buffer */
#define BufferLen	(33280u)  /*	320*104		*/

#pragma inline

typedef unsigned int WORD;
typedef unsigned char BYTE;

BYTE  Buffer[BufferLen]; 	/*  The screen buffer */
WORD Seed  =  0x3749;		/*  The seed value  */

#include "fire.pal"     		/* palette, generated with PAL */

BYTE far *Video = MK_FP( 0xa000, 0u );


void InitializeMCGA( void )
{
   asm {
	   MOV   AH, 00H     	/*  Set video mode */
	   MOV   AL, 13H     	/*  Mode 13h	*/
	   INT   10H        	/*  We are now in 320x200x256 */
       }
} /*--InitializeMCGA( )------*/

void SetUpPalette( void )
{
   asm {
	  .386
	  MOV   SI, OFFSET pal	/*  SI now points to the palette  */
	  MOV   CX, 768      	/*  Prepare for 768 OUTs */
	  MOV   DX, 03C8H       /*  Palette WRITE register */
	  XOR   AL, AL          /*  Start at color 0 */
	  CLI                  	/*  Disable interrupts */
	  OUT   DX, AL        	/*  Send value */
	  CLD                   /*  Forward direction */
	  INC   DX              /*  Now use palette DATA register */
	  REP   OUTSB           /*  768 multiple OUTs */
	  STI                   /*  Enable interrupts */
       }
} /*--SetUpPalette( )--------*/

BYTE Random( void )
{
   asm {
	   MOV   AX, Seed   	/*  Move the seed value into AX */
	   MOV   DX, 8405H  	/*  Move 8405H into DX */
	   MUL   DX         	/*  Put 8405H x Seed into DX:AX */
	   INC   AX         	/*  Increment AX */
	   MOV   Seed, AX   	/*  We have a new seed */
	}
   return( _DL );
} /*--Random( )---------*/

void AveragePixels( void )
{
   long i;
   for ( i = 320; i < BufferX*BufferY-BufferX ; ++i )
     {
	 Buffer[i-BufferX] = ( Buffer[i] + Buffer[i+1] + Buffer[i-1] + Buffer[i+BufferX] ) / 4;
	 if ( Buffer[i-BufferX]!=0 )
			Buffer[i-BufferX] -= 1;
     }
} /*--AveragePixels(  )-------*/

void TextMode( void )
{
   asm {
	   MOV   AH, 00H  	/* Set video mode */
	   MOV   AL, 03H   	/* Mode 03h */
	   INT   10H     	/* Enter 80x25x16 mode */
	}
} /*--TextMode( )----------*/

int main( void )
{
   unsigned long i, j, k;

   InitializeMCGA( );
   SetUpPalette( );
   while( !kbhit( ) )
    {
	AveragePixels( );
	for ( i = BufferX*BufferY - 2*BufferX; i < BufferX*BufferY; ++i )
		Buffer[i] = Random( );
	for( i=k=0; k<BufferY-4; ++k, i+=320 )
	   for( j=0 ; j<320; ++i, ++j  )
	     {
		Video[i] = Buffer[320*k+j];
		Video[i+320] = Buffer[320*k+j];
	     }
    }
   TextMode( );

   return(0);
} /*--main( )---------*/
/*------------------------
	Thank you Jesus!
_________________________end________________________________________*/
